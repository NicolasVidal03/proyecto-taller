// Componentes del módulo de Áreas GIS
export { default as AreaMap } from './AreaMap';
export { default as AreaTable } from './AreaTable';
export { default as AreaFormModal } from './AreaFormModal';
