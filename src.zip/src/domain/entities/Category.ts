export interface Category {
  id: number;
  name: string;
  description: string | null;
  state: boolean;
}
