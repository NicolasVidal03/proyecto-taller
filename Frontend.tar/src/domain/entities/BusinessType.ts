export interface BusinessType {
  id: number;
  name: string;
  state: boolean;
}