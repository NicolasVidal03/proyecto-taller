// Páginas del módulo de Áreas GIS
export { default as AreasPage } from './AreasPage';
