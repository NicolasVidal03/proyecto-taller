import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './presentation/providers/AuthProvider';
import { AppRoutes } from './presentation/routes/AppRoutes';

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
