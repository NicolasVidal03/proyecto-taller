export interface ClientType {
  id: number;
  name: string;
  description?: string;
  state: boolean;
}