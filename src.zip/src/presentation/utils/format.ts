export function formatRole(role?: string | null) {
  if (!role) return 'Sin rol';
  const map: Record<string, string> = {
    gerente: 'Gerente',
    administrador: 'Administrador',
    prevendedor: 'Prevendedor',
    transportista: 'Transportista',
  };
  if (role in map) return map[role as keyof typeof map];
  return role.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
}
