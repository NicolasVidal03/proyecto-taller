export interface Route {
  id: number;
  assignedDate: string;
  assignedIdUser: number;
  assignedIdArea: number;
}
