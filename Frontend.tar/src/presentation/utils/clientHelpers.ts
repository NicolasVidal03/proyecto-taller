

export const CLIENT_TYPES: Array<{ id: number; label: string }> = [
  { id: 1, label: 'Regular' },
  { id: 2, label: 'Minorista' },
  { id: 3, label: 'Mayorista' },
];

export function getClientTypeLabel(id?: number): string {
  if (!id) return 'Desconocido';
  const found = CLIENT_TYPES.find(c => c.id === id);
  return found ? found.label : `Tipo ${id}`;
}

export function getPriceByClientType(
  prices: Array<{ clientTypeId: number; price: number }> | undefined,
  clientTypeId: number
): number | null {
  if (!prices || prices.length === 0) return null;
  const priceInfo = prices.find(p => p.clientTypeId === clientTypeId);
  return priceInfo ? priceInfo.price : null;
}

export function getSuggestedPriceForClient(
  prices: Array<{ clientTypeId: number; price: number }> | undefined,
  clientTypeId: number
): number {
  const price = getPriceByClientType(prices, clientTypeId);
  if (price !== null) return price;
  
  const regular = getPriceByClientType(prices, 1);
  if (regular !== null) return regular;
  
  if (prices && prices.length > 0) return prices[0].price;
  
  return 0;
}
