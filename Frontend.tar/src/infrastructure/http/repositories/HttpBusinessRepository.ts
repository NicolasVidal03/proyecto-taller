import { http } from '../httpClient';
import { IBusinessRepository, CreateBusinessDTO, UpdateBusinessDTO } from '../../../domain/ports/IBusinessRepository';
import { Business } from '../../../domain/entities/Business';

export class HttpBusinessRepository implements IBusinessRepository {
  async getAll(): Promise<Business[]> {
    const res = await http.get('/business');
    const data = res.data || [];
    return data.map(this.mapBusinessResponse);
  }

  async getByClientId(clientId: number): Promise<Business[]> {
    const all = await this.getAll();
    return all.filter((b) => Number(b.clientId) === Number(clientId));
  }

  async create(data: CreateBusinessDTO, userId?: number | null): Promise<Business> {
    if (data.imageFile) {
      const fd = this.createFormData(data, userId);
      const res = await http.post('/business', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return this.mapBusinessResponse(res.data);
    }

    const payload = this.createPayload(data, userId);
    const res = await http.post('/business', payload);
    return this.mapBusinessResponse(res.data);
  }

  async update(id: number, data: UpdateBusinessDTO, userId?: number | null): Promise<Business | null> {
    if (data.imageFile) {
      const fd = this.createFormData(data, userId);
      const res = await http.patch(`/business/${id}`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return this.mapBusinessResponse(res.data);
    }

    const payload = this.createPayload(data, userId);
    const res = await http.patch(`/business/${id}`, payload);
    return this.mapBusinessResponse(res.data);
  }

  async softDelete(id: number, userId?: number | null): Promise<boolean> {
    await http.delete(`/business/${id}`, { data: { user_id: userId } });
    return true;
  }

  /**
   * Creates FormData for multipart requests
   */
  private createFormData(data: CreateBusinessDTO | UpdateBusinessDTO, userId?: number | null): FormData {
    const fd = new FormData();

    if (data.name !== undefined) fd.append('name', data.name);
    if (data.nit !== undefined && data.nit !== null) fd.append('nit', data.nit);
    if (data.address !== undefined && data.address !== null) fd.append('address', data.address);
    // accept either camelCase or snake_case in DTO
    if ((data as any).clientId !== undefined) fd.append('client_id', String((data as any).clientId));
    if ((data as any).client_id !== undefined) fd.append('client_id', String((data as any).client_id));
    if ((data as any).businessTypeId !== undefined) fd.append('business_type_id', String((data as any).businessTypeId));
    if ((data as any).business_type_id !== undefined) fd.append('business_type_id', String((data as any).business_type_id));
    const areaVal = (data as any).areaId !== undefined ? (data as any).areaId : (data as any).area_id;
    if (areaVal !== undefined) {
      fd.append('area_id', areaVal === null ? '' : String(areaVal));
    }
    if (data.position !== undefined && data.position !== null) {
      fd.append('position', JSON.stringify(data.position));
    }
    // handle both snake_case and camelCase
    if ((data as any).isActive !== undefined) fd.append('is_active', String((data as any).isActive));
    else if ((data as any).is_active !== undefined) fd.append('is_active', String((data as any).is_active));
    if (userId !== undefined && userId !== null) fd.append('user_id', String(userId));
    if (data.imageFile) fd.append('image', data.imageFile);

    return fd;
  }

  /**
   * Creates JSON payload with snake_case keys for backend
   */
  private createPayload(data: CreateBusinessDTO | UpdateBusinessDTO, userId?: number | null): Record<string, any> {
    const payload: Record<string, any> = {};

    if (data.name !== undefined) payload.name = data.name;
    if (data.nit !== undefined) payload.nit = data.nit;
    if (data.address !== undefined) payload.address = data.address;
    // accept either camelCase or snake_case keys
    if ((data as any).clientId !== undefined) payload.client_id = (data as any).clientId;
    if ((data as any).client_id !== undefined) payload.client_id = (data as any).client_id;
    if ((data as any).businessTypeId !== undefined) payload.business_type_id = (data as any).businessTypeId;
    if ((data as any).business_type_id !== undefined) payload.business_type_id = (data as any).business_type_id;
    const areaVal = (data as any).areaId !== undefined ? (data as any).areaId : (data as any).area_id;
    if (areaVal !== undefined) payload.area_id = areaVal;
    if (data.position !== undefined) payload.position = data.position;
    if ((data as any).isActive !== undefined) payload.is_active = (data as any).isActive;
    else if ((data as any).is_active !== undefined) payload.is_active = (data as any).is_active;
    if (userId !== undefined && userId !== null) payload.user_id = userId;

    return payload;
  }

  /**
   * Maps backend response (camelCase) to Business entity
   * Backend already returns camelCase in toResponse()
   */
  private mapBusinessResponse = (raw: any): Business => {
    if (!raw) throw new Error('Invalid business response');

    return {
      id: raw.id,
      name: raw.name,
      nit: raw.nit || null,
      position: raw.position || null,
      pathImage: raw.pathImage || null,
      address: raw.address || null,
      businessTypeId: raw.businessTypeId,
      clientId: raw.clientId,
      areaId: raw.areaId ?? null,
      isActive: raw.isActive ?? true,
    };
  };
}